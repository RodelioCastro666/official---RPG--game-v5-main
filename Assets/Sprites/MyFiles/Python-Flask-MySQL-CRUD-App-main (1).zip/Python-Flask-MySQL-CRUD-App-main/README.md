# Python-Flask-MySQL-CRUD-App
This is Python Flask CRUD Application with backend database MYSQL. It covers all operation that is create, read, edit and delete
